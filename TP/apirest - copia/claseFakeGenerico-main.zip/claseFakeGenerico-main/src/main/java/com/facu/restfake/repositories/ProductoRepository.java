package com.facu.restfake.repositories;



import com.facu.restfake.entities.Product;

import org.springframework.stereotype.Repository;

@Repository
public interface ProductoRepository extends BaseRepository<Product, Long>{
}
