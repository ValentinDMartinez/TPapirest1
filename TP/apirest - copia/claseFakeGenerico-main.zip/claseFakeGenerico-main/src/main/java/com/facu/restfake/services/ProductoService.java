package com.facu.restfake.services;


import com.facu.restfake.entities.Product;



public interface ProductoService extends BaseService<Product,Long> {





}


