package com.facu.restfake;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
